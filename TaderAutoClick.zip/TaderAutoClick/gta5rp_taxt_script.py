import os
import pyautogui
import time

print(os.getcwd())

pyautogui.FAILSAFE = False

accept_button = "C:/Users/ShiroKasamatsu/Desktop/TaderAutoClick/accept_button.png"
threshold = 0.8
numbers = [1, 2, 3]
notComplete = True
i = 0
animation = [
        " [=     ]",
        " [ =    ]",
        " [  =   ]",
        " [   =  ]",
        " [    = ]",
        " [     =]",
        " [    = ]",
        " [   =  ]",
        " [  =   ]",
        " [ =    ]",
    ]


print("Checking for accept button")

while True:
    try:
        launcher_location = pyautogui.locateOnScreen(accept_button, confidence=threshold)

        if launcher_location is not None:
            click_x = launcher_location.left + 20
            click_y = launcher_location.top + 15
            
            pyautogui.click(click_x, click_y)
            print("Accepted. Have a nice ride!")
            time.sleep(60)

    except pyautogui.ImageNotFoundException:
        print(animation[i % len(animation)], end='\r')
        time.sleep(0.1)
        i += 1